//
//  ViewController.swift
//  HCACodingChallenge
//
//  Created by devabhakthuni nomith sai chandra on 8/13/19.
//  Copyright © 2019 devabhakthuni nomith sai chandra. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var hcaTableView: UITableView!
    private let hcaService = HCAServiceModel()
    private var itemArray:[Item] = []
    
    private struct Attributes {
        static let title = "Home"
        static let baseUrlString = "https://api.stackexchange.com/2.2/questions?order=desc&sort=activity&site=stackoverflow"
        static let cellIdentifier = "HCACell"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.title = Attributes.title
        invokeApiCall()
    }
    
    //MARK: - Private Functions
    
    private func invokeApiCall() {
        self.hcaService.serviceCall(urlString: Attributes.baseUrlString) { [weak self] (success) in
            if success {
                DispatchQueue.main.async { [weak self] in
                    if let data = self?.hcaService.hcaData?.items {
                        self?.itemArray = data
                        self?.hcaTableView.reloadData()
                    }
                }
            }
        }
    }
    
    //MARK: - Tableview Delegates
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.itemArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var customCell = UITableViewCell()
        if let cell = tableView.dequeueReusableCell(withIdentifier: Attributes.cellIdentifier, for: indexPath) as? HCATabelViewCell {
            cell.nameLabel.text = self.itemArray[indexPath.row].owner?.displayName
            cell.titleLabel.text = self.itemArray[indexPath.row].title
            if let imageString = self.itemArray[indexPath.row].owner?.profileImage {
                if let urlImage = URL(string: imageString) {
                    cell.profileImage.load(url: urlImage)
                }
            }
            customCell = cell
        }
        return customCell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let urlString = self.itemArray[indexPath.row].link {
            if let url = URL(string: urlString) {
                UIApplication.shared.open(url)
            }
        }
    }
}


