//
//  HCAModel.swift
//  HCACodingChallenge
//
//  Created by devabhakthuni nomith sai chandra on 8/13/19.
//  Copyright © 2019 devabhakthuni nomith sai chandra. All rights reserved.
//

import Foundation

class HCAServiceModel: NSObject {
    
    internal var hcaData: HCADataModel?
    
    internal func serviceCall(urlString: String, complete: @escaping (Bool) -> Void) {
        guard let url = URL(string: urlString) else {
            return
        }
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            if error != nil {
                print("error")
            }
            guard let data = data else {
                return
            }
            do{
                self.hcaData = try JSONDecoder().decode(HCADataModel.self, from: data)
                complete(true)
            } catch let err {
                print("error", err)
                complete(false)
            }
        }.resume()
    
    }
}
