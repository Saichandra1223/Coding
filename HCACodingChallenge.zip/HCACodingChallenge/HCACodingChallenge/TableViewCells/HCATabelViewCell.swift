//
//  HCATabelViewCell.swift
//  HCACodingChallenge
//
//  Created by devabhakthuni nomith sai chandra on 8/13/19.
//  Copyright © 2019 devabhakthuni nomith sai chandra. All rights reserved.
//

import UIKit

class HCATabelViewCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var profileImage: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
